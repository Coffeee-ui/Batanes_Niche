# Task: Apply the new "Batanes Jobs" UI/UX design to the existing frontend

You are working on the existing **Batanes Jobs** job portal frontend (React + TypeScript, Vite, Tailwind CSS, Vitest). This is a **visual and UX refresh only**. Apply the design below to every page and shared component, including a Day mode (default) and a Night mode.

## 0. How to work

1. **Analyze the project first.** Before editing anything, read: `package.json`, `tailwind.config.js`, `src/index.css`, `index.html`, `src/App.tsx`, `src/components/layout/*`, `src/components/ui/*`, `src/components/forms/SkillSelector.tsx`, every file in `src/pages/**`, and `src/test/*`. Then write a short plan listing the files you will change and any decision you need to make (for example, how existing CSS variable names map to the tokens below).
2. **Presentation only.** Do not change API calls, routes, route guards, auth logic, context state, types, or data flow. Do not rename or remove props that other files use.
3. **Do not fix unrelated bugs.** If you notice bugs while working, list them in your final report instead of fixing them.
4. **Verification:** Only check for code errors. Run the type check, the linter, and the production build, and fix any errors you introduced. Do **not** run functional or manual verification, and do not start the app to click through it. The developer will verify behavior.
5. Keep existing tests passing. If a test fails only because of a class name or markup change, make the smallest fix to the test.

## 1. Non-negotiable rules

- **Only two frontend roles: Job Seeker and Employer.** There must be no admin role, option, link, or demo button anywhere in the frontend. Demo mode shows only "Job seeker demo" and "Employer demo".
- **Strict role separation.** Each role's navigation shows only its own links. Do not add links to pages the other role must not access.
- **Footer is plain text only. No buttons, no links.** Text: "Batanes Jobs · A local job portal for the province of Batanes. © 2026 All rights reserved."
- **Zero technical jargon in user-visible text.** Use plain everyday words. `zero_jargon.test.ts` must keep passing.
- **Light-touch copy changes.** Keep existing wording unless the design below specifies new wording.

## 2. Design direction

A combination of two ideas: a **clean professional structure** (dark gray header, clear cards, filters, tables, badges) with an **island-warm feel** (cream background, rounded corners, pill-shaped search bar, soft tiles, a Batanes hills and lighthouse illustration).

- **Day mode (default):** warm daylight. Cream background, white cards, amber-yellow primary, dark gray header, green status.
- **Night mode:** the same layout in cool tones, like Batanes under the moon. Deep navy background, slate-blue cards, softer "moon yellow" primary, teal-green status, and a night version of the illustration (crescent moon, stars, lighthouse beam).
- Color roles: **Yellow = primary** (main actions, active nav, highlights). **Dark gray = secondary** (header, footer, text, panels). **Green = tertiary** (success, "Hiring", "Interview", "Hired", completeness).
- Text on yellow is always the dark foreground color, never white.

## 3. Design tokens and theming

Day is the default. Night is applied by adding the class `dark` to the `<html>` element.

### 3.1 Token table

| Role | CSS variable | Day hex | Day HSL | Night hex | Night HSL |
|---|---|---|---|---|---|
| Background | `--background` | #FFF8E7 | `42 100% 95%` | #0B1320 | `217 49% 8%` |
| Surface | `--surface` | #FFFFFF | `0 0% 100%` | #142033 | `217 44% 14%` |
| Border | `--border` | #F1E3B8 | `45 67% 83%` | #25364D | `214 35% 22%` |
| Text | `--foreground` | #1A1D21 | `214 12% 12%` | #E6EDF5 | `212 43% 93%` |
| Muted text | `--muted-foreground` | #4A5058 | `214 9% 32%` | #9FB0C3 | `212 23% 69%` |
| Primary (yellow) | `--primary` | #F5B700 | `45 100% 48%` | #F2D36B | `46 84% 68%` |
| Primary hover | `--primary-hover` | #D99C00 | `43 100% 43%` | #E3BF4A | `46 73% 59%` |
| Text on primary | `--primary-foreground` | #1A1D21 | `214 12% 12%` | #101820 | `210 33% 9%` |
| Header | `--header` | #1A1D21 | `214 12% 12%` | #08101B | `215 54% 7%` |
| Header text | `--header-foreground` | #C5CBD1 | `210 12% 80%` | #9FB0C3 | `212 23% 69%` |
| Green badge background | `--tertiary-soft` | #D8F0E0 | `140 44% 89%` | #12372F | `167 51% 14%` |
| Green (tertiary) text | `--tertiary-foreground` | #124028 | `149 56% 16%` | #8FE3C8 | `161 60% 73%` |
| Pending badge background | `--warning-soft` | #FFE8D1 | `30 100% 91%` | #3B2F1E | `35 33% 17%` |
| Pending badge text | `--warning-foreground` | #8A4300 | `29 100% 27%` | #F4C98B | `35 83% 75%` |
| Neutral tag background | `--neutral-soft` | #EDEFF1 | `210 12% 94%` | #1E2D42 | `215 38% 19%` |
| Neutral tag text | `--neutral-foreground` | #343A41 | `212 11% 23%` | #C5D2E0 | `211 30% 83%` |
| Link | `--link` | #A87500 | `42 100% 33%` | #F2D36B | `46 84% 68%` |
| Selected chip background | `--highlight` | #FFF1BF | `47 100% 87%` | #2A3446 | `219 25% 22%` |
| Footer | `--footer` | #1A1D21 | `214 12% 12%` | #08101B | `215 54% 7%` |
| Footer text | `--footer-foreground` | #C5CBD1 | `210 12% 80%` | #9FB0C3 | `212 23% 69%` |
| Error badge background | `--danger-soft` | #FDE2E2 | `0 87% 94%` | #3D1F28 | `342 33% 18%` |
| Error badge text | `--danger-foreground` | #8A1C1C | `0 66% 33%` | #F5B5BF | `351 76% 84%` |

### 3.2 Implementation

1. In `src/index.css`, define these as HSL triplets (no `hsl()` wrapper) under `:root` for Day and `.dark` for Night. **Reuse the existing variable names if the file already has equivalents**, and add the missing ones.

```css
:root {
  --background: 42 100% 95%;
  --surface: 0 0% 100%;
  --border: 45 67% 83%;
  --foreground: 214 12% 12%;
  --muted-foreground: 214 9% 32%;
  --primary: 45 100% 48%;
  --primary-hover: 43 100% 43%;
  --primary-foreground: 214 12% 12%;
  --header: 214 12% 12%;
  --header-foreground: 210 12% 80%;
  --tertiary-soft: 140 44% 89%;
  --tertiary-foreground: 149 56% 16%;
  --warning-soft: 30 100% 91%;
  --warning-foreground: 29 100% 27%;
  --neutral-soft: 210 12% 94%;
  --neutral-foreground: 212 11% 23%;
  --link: 42 100% 33%;
  --highlight: 47 100% 87%;
  --footer: 214 12% 12%;
  --footer-foreground: 210 12% 80%;
  --danger-soft: 0 87% 94%;
  --danger-foreground: 0 66% 33%;
}
.dark {
  --background: 217 49% 8%;
  --surface: 217 44% 14%;
  --border: 214 35% 22%;
  --foreground: 212 43% 93%;
  --muted-foreground: 212 23% 69%;
  --primary: 46 84% 68%;
  --primary-hover: 46 73% 59%;
  --primary-foreground: 210 33% 9%;
  --header: 215 54% 7%;
  --header-foreground: 212 23% 69%;
  --tertiary-soft: 167 51% 14%;
  --tertiary-foreground: 161 60% 73%;
  --warning-soft: 35 33% 17%;
  --warning-foreground: 35 83% 75%;
  --neutral-soft: 215 38% 19%;
  --neutral-foreground: 211 30% 83%;
  --link: 46 84% 68%;
  --highlight: 219 25% 22%;
  --footer: 215 54% 7%;
  --footer-foreground: 212 23% 69%;
  --danger-soft: 342 33% 18%;
  --danger-foreground: 351 76% 84%;
}
```

2. In `tailwind.config.js`, set `darkMode: 'class'` and map each token to `hsl(var(--token) / <alpha-value>)` so classes like `bg-background`, `bg-surface`, `text-foreground`, `text-muted-foreground`, `bg-primary`, `text-primary-foreground`, `border-border`, `bg-tertiary-soft`, and `text-tertiary-foreground` work. Remove or replace the old custom palette so no component keeps hard-coded colors.
3. Add `src/contexts/ThemeContext.tsx` (provider and hook). It reads and writes the choice to `localStorage` (key `theme`, values `light` or `dark`), defaults to `light` when nothing is saved, and toggles the `dark` class on `document.documentElement`. Wrap the app in it in `main.tsx`.
4. Add a small inline script in `index.html` that applies the saved theme class before the app renders, to avoid a flash of the wrong theme.
5. Add a **sun/moon icon button** to the Navbar for everyone (guests and both roles), placed before the Sign in / Sign up buttons or the notification bell. Its accessible label is "Switch to night mode" in Day and "Switch to day mode" in Night. Minimum size 44 by 44 px.
6. **Font:** Plus Jakarta Sans (weights 400, 500, 700, 800) with `system-ui, sans-serif` fallback. Load it through the existing font approach or a `<link>` in `index.html`.
7. **Shape and spacing:** buttons and inputs 10px radius; cards 16px; category tiles 20px; badges, chips, and the search pill fully rounded. Spacing scale 4, 8, 12, 16, 24, 32, 48. Card padding 20px.

## 4. Component specifications

- **Navbar (`Navbar.tsx`):** Header background uses the `header` token in both modes. Left: yellow circle mark plus "Batanes Jobs" (800 weight, 20px). Center: links. Active link is `primary` colored with a 3px underline. Right: theme toggle, then either **Sign in** (outlined) and **Sign up** (yellow) for guests, or the notification bell (with a yellow unread dot) and a round yellow initial avatar for signed-in users. Keep the existing role-aware menu logic. Employer links: Dashboard, My Jobs, Candidates, Post a Job, Profile. Job seeker links: Dashboard, Browse Jobs, Applications, Saved Jobs, Profile. Guests: Browse Jobs, For Employers. It must wrap cleanly on small screens.
- **Footer (`Footer.tsx`):** `footer` token background, `footer-foreground` text, plain text only.
- **Buttons:** Primary = yellow background with dark text, hover `primary-hover`. Secondary = surface background with 2px border. Ghost (on header only) = transparent with a light border and white text. Minimum height 44px, weight 700. Exactly one primary button per area.
- **Inputs and selects:** visible label above (13px, 700), 48px tall, 10px radius, `border` token border, surface background. Focus: 3px `primary` outline. Textareas have 12px padding and 120px minimum height. **Keep the gap between stacked fields compact (about 16px).**
- **Search pill (landing and Jobs):** one rounded container with the keyword input, the municipality select, and a yellow "Search jobs" button inside it. It wraps on small screens.
- **Chips (category, job type, skills, municipality, tabs):** 44px tall, fully rounded, surface background with border. Selected chips use the `highlight` background with a `primary` border.
- **Badges:** fully rounded, 12px, 700 weight. Green (`tertiary-soft` / `tertiary-foreground`) for Hiring, Active, Interview, Hired, Done. Pending uses `warning-soft` / `warning-foreground`. Rejected or not selected uses `danger-soft` / `danger-foreground`. Closed and neutral tags use `neutral-soft` / `neutral-foreground`. Always show a text label, never color alone.
- **Cards (`JobCard.tsx` and general):** surface background, 1px `border`, 16px radius. `JobCard` layout: category tag and green "Hiring" badge on the first line, job title (17px, 700), meta line (employer or place, municipality, job type, posted time) in muted text, and on the right the bookmark toggle button (44px, outlined; filled with primary when saved) and a yellow "View job" button. Keep the existing bookmark behavior.
- **Tables (applications, applicants):** header row 12px muted bold, rows separated by a `border` line, inside a horizontally scrollable card on small screens.
- **Progress bar (profile completeness):** 10px high, rounded, `neutral-soft` track, `tertiary-foreground` fill.
- **Notifications list:** rows with a yellow unread dot, a bold title, and muted detail text, separated by `border` lines.
- **Six-digit code input (Forgot password):** six 48 by 56 px boxes, 22px bold centered digit, with a progress bar above ("Step 2 of 3").
- **Role choice (Register):** two selectable cards, "I'm looking for work" (Job seeker) and "I'm hiring" (Employer). The selected card has the `highlight` background and a `primary` border.
- **SkillSelector:** skills as selectable chips with an "Other…" chip that reveals the custom input, keeping the current logic.
- **Toasts and modals:** use `surface`, `border`, and the badge colors above.
- **Landscape illustration (`src/components/ui/BatanesScene.tsx`, new):** an inline SVG of rolling hills and a lighthouse with a Day variant (sun, three green hills) and a Night variant (crescent moon, stars, teal-navy hills, a soft yellow lighthouse beam). It switches with the theme and has an accessible label. Use it at the bottom of the landing page above the footer, and optionally on the Login and Register backgrounds.

## 5. Page by page

Every page uses the shared `Layout` (Navbar, content, Footer). All pages need Day and Night to look correct.

- **`LandingPage.tsx`:** Centered hero: a small green badge "Made for the islands of Batanes", a large headline "Work that keeps you close to home.", a short sentence, then the search pill. Below it, municipality chips (Basco, Mahatao, Ivana, Uyugan, Sabtang · by boat, Itbayat · by boat). Then "Popular on the islands" as six rounded category tiles (Tourism, Fishing, Farming, Construction, Transport, Retail). Then "Latest openings" with three `JobCard`s and a "View all jobs" link. Then two panels: "Looking for work?" and "Hiring in Batanes?" (the second is the dark panel). End with the Batanes scene and the footer.
- **`JobsPage.tsx`:** Title, search pill, then a two-column layout: a filter card on the left (Category chips, Job type chips, Clear filters button) and a list of `JobCard`s on the right. On small screens the filters stack above the list.
- **`JobDetailPage.tsx`:** Breadcrumb, then a large card with tag and Hiring badge, title, meta, "About the job", "Requirements" list, and skills tags. A side card holds "Apply for this job" (profile completeness hint, yellow Apply now, secondary Save job) plus location and contact notes.
- **`LoginPage.tsx`:** Centered card on a tinted background. Fields: Email, Password. "Forgot password?" link, yellow Sign in, a Sign up link, and a "Demo mode" section with two secondary buttons: Job seeker demo and Employer demo.
- **`RegisterPage.tsx`:** Centered card with the two role cards, then Full name, Email, Municipality, Password, and a yellow Create account button.
- **`ForgotPasswordPage.tsx`:** Centered card with step text and progress bar, the six-digit boxes, Verify code, "Send a new code", and "Back to sign in". Keep all existing steps.
- **`DashboardPage.tsx` (Job seeker view):** Greeting ("Good morning" in Day, "Good evening" in Night), stats cards (Applications, Interviews, Saved jobs), "Recommended for you" with `JobCard`s, "Recent applications" with status badges, and a side card with the profile completeness gauge and a "Complete profile" button.
- **`DashboardPage.tsx` (Employer view):** Same top navbar layout (**no sidebar**). Greeting and a yellow "Post a job" button, four stat cards (Active jobs, New applicants, Interviews, Hired), and a "Recent applicants" table with status badges and a Review link.
- **`MyJobsPage.tsx`:** Title with a yellow "Post a job" button, Active and Closed tabs, and job rows showing status, applicant count badge, Edit, and Close job (or Reopen for closed jobs).
- **`PostJobPage.tsx`:** A single card form: Job title, Category, Municipality, Job type, Description, Skills chips (with Other…), then Save draft (secondary) and Publish job (yellow).
- **`CandidatesPage.tsx`:** Skill and municipality search, then "Recommended for ..." candidate cards with initial avatar, name, municipality, skill tags, a match badge, and a "View profile" button.
- **`ApplicationsPage.tsx`:** Status tabs (All, Pending, Interview, Hired, Closed) and a table with Job, Municipality, Applied, Status badge, and View.
- **`SavedJobsPage.tsx`:** List of `JobCard`s with the bookmark shown as filled/active, which removes the job when toggled (keep existing behavior).
- **`NotificationsPage.tsx`:** Title, "Mark all as read" secondary button, and the notification list card.
- **`ProfilePage.tsx`:** A side card with avatar, name, municipality, the completeness gauge, and Done / To do items. A main form card with Full name, Email, Phone or Messenger, Municipality, Short bio, Skills chips, and Cancel / Save changes.

## 6. Batanes localization (keep)

- Municipality options everywhere: All of Batanes, Basco, Mahatao, Ivana, Uyugan, Sabtang, Itbayat. Show a "by boat" hint for Sabtang and Itbayat on the landing chips.
- Local categories: Tourism, Fishing, Farming, Construction, Transport, Retail.
- Keep the app light: no heavy images or animation, use skeleton loaders over spinners where easy, and make everything work well on a mid-range phone.
- Plain, friendly wording. Phone or Messenger is a valid contact option.

## 7. Accessibility and responsive rules

- Text contrast at least 4.5:1 (large text 3:1) in **both** modes. Never put white text on yellow.
- Visible keyboard focus on every interactive element. Touch targets at least 44 by 44 px.
- Real `button`, `a`, `label`, and `input` elements. Icon-only buttons need an `aria-label`. Decorative SVGs get `aria-hidden="true"`.
- Mobile first. No horizontal page scroll. Wide tables scroll inside their own container.
- Motion: only subtle 150 to 250 ms transitions, and respect `prefers-reduced-motion`.

## 8. Suggested order of work

1. Tokens, Tailwind mapping, `ThemeContext`, `index.html` script, font.
2. Shared pieces: Navbar (with toggle), Footer, buttons, inputs, chips, badges, cards, `JobCard`, tables, progress bar, `BatanesScene`, `ui/index.tsx` (Spinner, Modal), `Toast`, `SkillSelector`.
3. Public pages: Landing, Jobs, JobDetail, Login, Register, ForgotPassword.
4. Job seeker pages: Dashboard, Applications, SavedJobs, Notifications, Profile.
5. Employer pages: Dashboard, MyJobs, PostJob, Candidates.
6. Search the code for leftover hard-coded colors (hex, rgb, and old palette class names) and replace them with tokens.
7. Run the type check, linter, and production build, and fix errors.

## 9. Final report

When done, reply with: (1) the list of files created and changed, (2) any decisions you made about existing variable or class names, (3) bugs or issues you noticed but did not fix, and (4) the results of the type check, lint, and build. Do not claim functional testing was done.
